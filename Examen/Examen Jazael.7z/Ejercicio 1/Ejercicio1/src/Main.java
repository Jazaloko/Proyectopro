public class Main {
    public static void main(String[] args) {

        float f = 23f;
        double d = 3;

        double x = f*d/3;

        System.out.println(x);

        System.out.println(f%4);

    }
}